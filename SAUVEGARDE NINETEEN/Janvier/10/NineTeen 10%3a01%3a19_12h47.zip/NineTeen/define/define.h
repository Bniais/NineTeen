#include <SDL.h>

#define TRUE  1
#define FALSE  0
#define PI 3.1415


// launcher params
#define LAUNCHER_WIDTH_SIZE 640
#define LAUNCHER_HEIGHT_SIZE 480

// error code //
#define SDL_CREATE_WINDOW_ECHEC -100
#define SDL_LOAD_BMP_ECHEC -101
#define SDL_CREATE_TEXTURE_FROM_SURFACE_ECHEC -102
#define SDL_CREATE_TEXTURE_ECHEC -103

#define FILE_NOT_FOUND -201
#define FILE_CORRUPTED -202

#define SHAPE_SIZE 500

//Window
#define WINDOW_FLAG 0


//Colors
const SDL_Color Black = {0, 0, 0, 255};
const SDL_Color White = {255, 255, 255, 255};
