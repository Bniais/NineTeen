#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>


int room(SDL_Window *window, SDL_Renderer *renderer,char *identifiant, char* token);
