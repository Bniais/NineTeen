genre là tu peux venir ?

juste parce que j'ai ouvert ?
