#include <stdlib.h>
#include <stdio.h>
#include <SDL_image.h>
#include <SDL.h>
#include <math.h>


int launchSnake();
